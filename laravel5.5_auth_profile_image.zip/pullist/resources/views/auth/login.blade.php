@extends('layouts.app')

@section('content')
<div class="main">
<div class="container">
<div class="wraper">
  <div class="login-area">
    <h2>Pullist</h2>
    <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                        {{ csrf_field() }}


     <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <!-- <label for="email" class="col-md-4 control-label">E-Mail Address</label> -->

                          
                                <input id="email" type="email" class="form-control" placeholder="Email" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                       
 
   
    <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <!-- <label for="password" class="col-md-4 control-label">Password</label> -->

                            
                                <input id="password" placeholder="Password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                       

   <button type = "submit" class = "btn btn-default">Submit</button>
    <p>Dont't have a ccount?</p> 
   <a href="{{ route('register') }}" class = "btn btn-default" >Sign Up</a>
 
  </div>
  <p class="forget"><a class="btn btn-link" href="{{ route('password.request') }}">
                                    Forgot Your Password?
                                </a></p>
  </div>
    </form>
</div>
</div>
@endsection
