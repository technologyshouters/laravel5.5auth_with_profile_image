@extends('layouts.app')

@section('content')
<div class="main">
<div class="container">
<div class="wraper sign">
  <div class="login-area">
    <h2>Pullist</h2>
     <form class="form-horizontal" method="POST" action="{{ route('register') }}">
                        {{ csrf_field() }}

    <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                           <!--  <label for="name" class="col-md-4 control-label">Name</label> -->

                   
                                <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" placeholder="First name" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                       
                        </div>


              <div class="form-group{{ $errors->has('Last_name') ? ' has-error' : '' }}">
                            <!-- <label for="name" class="col-md-4 control-label">Name</label> -->

                     
                                <input id="Last_name" type="text" class="form-control" placeholder="Last name" name="Last_name" value="{{ old('Last_name') }}" required autofocus>

                                @if ($errors->has('Last_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('Last_name') }}</strong>
                                    </span>
                                @endif
                           
                        </div>


                      <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <!-- <label for="email" class="col-md-4 control-label">E-Mail Address</label> -->

                                <input id="email" type="email" class="form-control" placeholder="Email" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                  
                        </div>



     <div class="form-group{{ $errors->has('phone') ? ' has-error' : '' }}">
                            <!-- <label for="password" class="col-md-4 control-label">Password</label> -->

                   
                                <input id="phone" placeholder="Mobile Number" type="text" class="form-control" name="phone" required>

                                @if ($errors->has('phone'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('phone') }}</strong>
                                    </span>
                                @endif
                         
                        </div>


   <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <!-- <label for="password" class="col-md-4 control-label">Password</label> -->

                   
                                <input id="password" placeholder="Password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                         
                        </div>
<!--  <div class="form-group">
                           


                                <input id="password-confirm" placeholder="Confirm Password" type="password" class="form-control" name="password_confirmation" required>
                            
                        </div> -->


   <button type = "submit" class = "btn btn-default">Submit</button>
   </form>
  </div>
  </div>
</div>
</div>
@endsection
