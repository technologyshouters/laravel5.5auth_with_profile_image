<?php $__env->startSection('content'); ?>
<div class="main">
<div class="container">
<div class="wraper">
  <div class="login-area">
    <h2>Pullist</h2>
    <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>



     <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <!-- <label for="email" class="col-md-4 control-label">E-Mail Address</label> -->

                          
                                <input id="email" type="email" class="form-control" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                       
 
   
    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <!-- <label for="password" class="col-md-4 control-label">Password</label> -->

                            
                                <input id="password" placeholder="Password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                       

   <button type = "submit" class = "btn btn-default">Submit</button>
    <p>Dont't have a ccount?</p> 
   <a href="<?php echo e(route('register')); ?>" class = "btn btn-default" >Sign Up</a>
 
  </div>
  <p class="forget"><a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    Forgot Your Password?
                                </a></p>
  </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>